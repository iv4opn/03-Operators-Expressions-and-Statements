﻿using System;

class CalcReactArea
{
    static void Main()
    {
        Console.WriteLine("Enter the side hight.");
        int a = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter the side lenght.");
        int b = int.Parse(Console.ReadLine());
        Console.WriteLine("Area of reactangle is:" + a * b);

    }
}

