﻿using System;

class OddOrEven
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        if (n % 2 == 0)
        { Console.WriteLine("Entered number is odd."); }
        else
        { Console.WriteLine("Entered number is even."); }

    }

}
