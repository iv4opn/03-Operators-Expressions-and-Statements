﻿using System;

class CheckDevidedNum
{
    static void Main()
    {
        Console.WriteLine("Enter devide number:");
        int n = int.Parse(Console.ReadLine());
         //The result is same if divide entered number on 35
        if ((n % 5 == 0) && (n % 7 == 0))
        { Console.WriteLine(true); }
        else
        { Console.WriteLine(false); }

    }
}
