﻿using System;

class CheckNum7
{
    static void Main()
    {
        Console.WriteLine("Enter the number:");
        int n = int.Parse(Console.ReadLine());
        int a = n / 100;
        a = a % 10;
        bool checkVar = (a == 7);
        Console.WriteLine("The third number is {0}, the expresion is:{1}", a, checkVar);


    }
}

